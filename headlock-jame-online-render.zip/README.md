# Headlock Jame Online API

Bộ source gồm:
- Frontend trong thư mục `public/`
- Backend Node.js + Express
- MongoDB lưu key online
- Route đăng nhập: `POST /check-key`
- Route admin tạo/xóa/xem key

> Lưu ý: giao diện này chỉ là UI/license demo, không can thiệp game hoặc thiết bị.

## 1. Upload lên GitHub

Tạo repository mới, upload toàn bộ file trong thư mục này lên GitHub.

## 2. Tạo MongoDB miễn phí

Vào MongoDB Atlas, tạo database miễn phí, lấy chuỗi kết nối dạng:

```txt
mongodb+srv://USER:PASS@cluster.mongodb.net/headlock-jame
```

## 3. Deploy Render

Vào Render → New → Web Service → Connect GitHub repo.

Cài đặt:

```txt
Build Command: npm install
Start Command: npm start
```

Environment Variables:

```txt
PORT=10000
MONGODB_URI=mongodb+srv://USER:PASS@cluster.mongodb.net/headlock-jame
ADMIN_TOKEN=mat-khau-admin-cua-ban
PUBLIC_BASE_URL=https://ten-app.onrender.com
```

## 4. Kiểm tra API

Mở:

```txt
https://ten-app.onrender.com/health
```

Nếu thấy `API online is running` là OK.

## 5. Tạo key online

Dùng Postman, Thunder Client hoặc terminal:

```bash
curl -X POST https://ten-app.onrender.com/admin/create-key \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer mat-khau-admin-cua-ban" \
  -d '{"key":"VIP2026","days":1,"maxSlots":200,"note":"key test"}'
```

Hoặc tạo key random:

```bash
curl -X POST https://ten-app.onrender.com/admin/create-key \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer mat-khau-admin-cua-ban" \
  -d '{"prefix":"JAME","days":30,"maxSlots":1}'
```

## 6. Xem danh sách key

```bash
curl https://ten-app.onrender.com/admin/keys \
  -H "Authorization: Bearer mat-khau-admin-cua-ban"
```

## 7. Xóa key

```bash
curl -X POST https://ten-app.onrender.com/admin/delete-key \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer mat-khau-admin-cua-ban" \
  -d '{"key":"VIP2026"}'
```

## 8. Sửa link API trong frontend

Nếu frontend và backend chạy chung Render, `public/script.js` để nguyên:

```js
const API_BASE = window.location.origin;
```

Nếu dùng GitHub Pages riêng, sửa thành:

```js
const API_BASE = "https://ten-app.onrender.com";
```
