// ================= HEADLOCK JAME CONFIG =================
// Khi chạy cùng Render backend, để API_BASE = window.location.origin.
// Nếu tách frontend ra GitHub Pages, đổi thành link Render của bạn.
const API_BASE = window.location.origin;
const GET_KEY_FREE_URL = "https://link4m.net/LrM89eO";
const CONTACT_ZALO = "https://zalo.me/0333635135";

const STORAGE = {
  DEVICE: "headlock-jame-device-id",
  KEY: "headlock-jame-key",
  SESSION: "headlock-jame-unlocked",
  VERSION: "headlock-jame-freefire-version",
  EXPIRE: "headlock-jame-expire"
};

const passwordScreen = document.getElementById("passwordScreen");
const mainApp = document.getElementById("mainApp");
const passwordForm = document.getElementById("passwordForm");
const passwordInput = document.getElementById("passwordInput");
const passwordError = document.getElementById("passwordError");
const togglePassword = document.getElementById("togglePassword");
const logoutBtn = document.getElementById("logoutBtn");
const contactBtn = document.getElementById("contactBtn");
const getKeyBtn = document.getElementById("getKeyBtn");
const infoGetKeyBtn = document.getElementById("infoGetKeyBtn");
const licenseText = document.getElementById("licenseText");
const actions = document.querySelectorAll(".feature-card");
const versionModal = document.getElementById("versionModal");
const boostModal = document.getElementById("boostModal");
const terminal = document.getElementById("terminal");
const boostDone = document.getElementById("boostDone");
const statusText = document.getElementById("statusText");
const onBtn = document.getElementById("onBtn");
const offBtn = document.getElementById("offBtn");
const toast = document.getElementById("toast");
const infoPanel = document.getElementById("infoPanel");
const overlay = document.getElementById("overlay");
document.getElementById("apiText").textContent = API_BASE;

const terminalLines = [
  "$ Initializing demo optimization...",
  "$ Checking license session...",
  "$ Loading interface modules...",
  "$ Applying UI settings...",
  "$ Finalizing demo panel..."
];

function getDeviceId() {
  let deviceId = localStorage.getItem(STORAGE.DEVICE);
  if (!deviceId) {
    deviceId = "JAME-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2, 10).toUpperCase();
    localStorage.setItem(STORAGE.DEVICE, deviceId);
  }
  return deviceId;
}

function setLoginMessage(type, text) {
  passwordError.className = "message " + (type || "");
  passwordError.textContent = text;
}

function showToast(text) {
  toast.textContent = text;
  toast.classList.add("active");
  clearTimeout(window.headlockToastTimer);
  window.headlockToastTimer = setTimeout(() => toast.classList.remove("active"), 1800);
}

function formatDate(value) {
  if (!value) return "vĩnh viễn";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString("vi-VN");
}

async function checkKeyOnline(key) {
  const res = await fetch(API_BASE + "/check-key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key, deviceId: getDeviceId() })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.message || "Không kết nối được API /check-key.");
  return data;
}

function unlockApp(message = "Đã mở khóa") {
  document.body.classList.add("unlocked");
  passwordScreen.classList.add("hidden");
  mainApp.classList.remove("locked");
  logoutBtn.classList.remove("hidden");
  licenseText.textContent = message;
  sessionStorage.setItem(STORAGE.SESSION, "true");
}

function lockApp() {
  document.body.classList.remove("unlocked");
  passwordScreen.classList.remove("hidden");
  mainApp.classList.add("locked");
  logoutBtn.classList.add("hidden");
  passwordInput.value = "";
  sessionStorage.removeItem(STORAGE.SESSION);
  localStorage.removeItem(STORAGE.KEY);
  localStorage.removeItem(STORAGE.EXPIRE);
  setLoginMessage("", "Zalo hỗ trợ: 0333635135");
}

async function loginWithValue(value) {
  setLoginMessage("", "Đang kiểm tra key online...");
  const result = await checkKeyOnline(value);
  if (!result.success) throw new Error(result.message || "Key không hợp lệ");
  localStorage.setItem(STORAGE.KEY, value);
  if (result.expiresAt) localStorage.setItem(STORAGE.EXPIRE, new Date(result.expiresAt).getTime());
  unlockApp(`\n🔓 LOGIN SUCCESS\n\n🔑 Key: ${value}\n🕒 Hết hạn: ${formatDate(result.expiresAt)}\n🎟 Slot: ${result.usedSlots || 0}/${result.maxSlots || "?"}\n`);
}

async function autoLogin() {
  const savedKey = localStorage.getItem(STORAGE.KEY);
  if (!savedKey || sessionStorage.getItem(STORAGE.SESSION) !== "true") return;
  const expire = Number(localStorage.getItem(STORAGE.EXPIRE));
  if (!expire || Date.now() > expire) return lockApp();
  unlockApp("Key hết hạn: " + new Date(expire).toLocaleString("vi-VN"));
}

passwordForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const value = passwordInput.value.trim();
  if (!value) return setLoginMessage("err", "Vui lòng nhập key.");
  try { await loginWithValue(value); passwordInput.value = ""; }
  catch (error) { setLoginMessage("err", error.message || "Đăng nhập thất bại."); passwordInput.select(); }
});

togglePassword.addEventListener("click", () => {
  const isPassword = passwordInput.type === "password";
  passwordInput.type = isPassword ? "text" : "password";
  togglePassword.textContent = isPassword ? "🙈" : "👁";
});

logoutBtn.addEventListener("click", lockApp);
contactBtn.addEventListener("click", () => window.open(CONTACT_ZALO, "_blank"));
function openGetKeyFree() { window.open(GET_KEY_FREE_URL, "_blank"); }
getKeyBtn.addEventListener("click", openGetKeyFree);
infoGetKeyBtn.addEventListener("click", openGetKeyFree);

document.getElementById("menuBtn").addEventListener("click", () => { infoPanel.classList.add("active"); overlay.classList.remove("hidden"); });
document.getElementById("closeInfo").addEventListener("click", closeAll);
overlay.addEventListener("click", closeAll);
function closeAll() { infoPanel.classList.remove("active"); overlay.classList.add("hidden"); versionModal.classList.add("hidden"); boostModal.classList.add("hidden"); }
function openModal(modal) { modal.classList.remove("hidden"); overlay.classList.remove("hidden"); }
function closeModal(modal) { modal.classList.add("hidden"); if (versionModal.classList.contains("hidden") && boostModal.classList.contains("hidden") && !infoPanel.classList.contains("active")) overlay.classList.add("hidden"); }
document.querySelectorAll("[data-close]").forEach(btn => btn.addEventListener("click", () => { closeModal(versionModal); closeModal(boostModal); }));
function openVersionModal() { openModal(versionModal); }
function runBoost() { terminal.textContent = ""; boostDone.classList.add("hidden"); openModal(boostModal); let index = 0; const timer = setInterval(() => { terminal.textContent += terminalLines[index] + "\n"; index++; if (index >= terminalLines.length) { clearInterval(timer); setTimeout(() => boostDone.classList.remove("hidden"), 450); } }, 380); }
actions.forEach(card => card.addEventListener("click", () => { const action = card.dataset.action; card.classList.toggle("active"); if (action === "boost") { runBoost(); return showToast("Đã chạy demo BOST RAM"); } if (action === "headlock" || action === "reg") { openVersionModal(); return showToast("Chọn phiên bản"); } if (action === "fix") { statusText.textContent = "Demo setting activated."; showToast("Đã bật demo setting"); } }));
document.querySelectorAll(".version-btn").forEach(btn => btn.addEventListener("click", () => { document.querySelectorAll(".version-btn").forEach(i => i.classList.remove("active")); btn.classList.add("active"); localStorage.setItem(STORAGE.VERSION, btn.dataset.version); statusText.textContent = `${btn.dataset.version} selected. UI demo ready!`; onBtn.classList.add("active"); offBtn.classList.remove("active"); }));
document.getElementById("successBtn").addEventListener("click", () => { statusText.textContent = "Demo panel is ON"; onBtn.classList.add("active"); offBtn.classList.remove("active"); closeModal(versionModal); showToast("Đã bật giao diện demo"); });
document.getElementById("dangerBtn").addEventListener("click", () => { statusText.textContent = "Demo panel is OFF"; offBtn.classList.add("active"); onBtn.classList.remove("active"); closeModal(versionModal); showToast("Đã tắt giao diện demo"); });
onBtn.addEventListener("click", () => { onBtn.classList.add("active"); offBtn.classList.remove("active"); statusText.textContent = "Panel is ON"; openVersionModal(); });
offBtn.addEventListener("click", () => { offBtn.classList.add("active"); onBtn.classList.remove("active"); statusText.textContent = "Panel is OFF"; showToast("Đã tắt panel"); });
autoLogin();
